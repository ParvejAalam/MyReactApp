import React from 'react';

const Faq = () => {
    return (
        <div>
            <h3>Hello Faq</h3>
        </div>
    );
};

export default Faq;