import React from 'react';
import Movie from './Movie';
const App = () => {
  return (
    <div>
      <Movie/>
    </div>
  );
};

export default App;
